# Eyewear Form Research 300

Generated on 2026-06-24.

Total usable product images: 300.
New images beyond prior 100: 200.

- Armani Exchange: 14
- Burberry: 18
- Coach: 14
- Emporio Armani: 11
- Gentle Monster: 2
- Giorgio Armani: 16
- Jimmy Choo: 18
- MOSCOT: 16
- Michael Kors: 18
- Miu Miu: 18
- Moncler: 14
- Oakley: 14
- Oliver Peoples: 15
- Persol: 13
- Polo Ralph Lauren: 16
- Prada: 18
- Prada Linea Rossa: 18
- Ralph: 13
- Ray-Ban: 20
- Versace: 14

Use `preference_board.html` for quick personal form picks. Use `metadata.csv` and `image_location_index.csv` for source and file tracking. Images are for private research/reference; verify usage rights before public presentation.
